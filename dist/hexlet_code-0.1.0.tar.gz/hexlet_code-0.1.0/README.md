### Hexlet tests and linter status:
[![Actions Status](https://github.com/EvgeniyPy/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/EvgeniyPy/python-project-49/actions)

<a href="https://codeclimate.com/github/EvgeniyPy/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/1b28161c9327fc9dfe74/maintainability" /></a>





### Пример игры
[![asciicast](https://asciinema.org/a/580561.svg)](https://asciinema.org/a/580561)

