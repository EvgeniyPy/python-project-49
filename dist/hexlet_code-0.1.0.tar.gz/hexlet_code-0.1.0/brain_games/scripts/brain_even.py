from random import randint
import prompt



random = randint(1, 100)

def lets_play():
    print('''Answer "yes" if the number is even, otherwise answer "no".''')
    print('Question:', random)

def even_num():
    name = prompt.string('Your answer:')
    
