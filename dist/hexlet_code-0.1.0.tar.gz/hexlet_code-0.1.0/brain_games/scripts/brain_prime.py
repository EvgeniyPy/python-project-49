from brain_games.games import letsprime
from brain_games.game_engine import launch_game


def main():
    launch_game(letsprime)


if __name__ == '__main__':
    main()
