from brain_games import cli
from scripts.brain_games import brain_even 


def main():
    print("Welcome to the Brain Games!")
    cli.welcome_user()
    brain_even.even_num()
if __name__ == '__main__':
    main()
