from brain_games.games import letscalc
from brain_games.game_engine import launch_game


def main():
    launch_game(letscalc)


if __name__ == '__main__':
    main()
