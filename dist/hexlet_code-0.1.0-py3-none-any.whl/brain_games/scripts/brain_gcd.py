from brain_games.games import letsgcd
from brain_games.game_engine import launch_game


def main():
    launch_game(letsgcd)


if __name__ == '__main__':
    main()
