from brain_games.games import gcd_game
from brain_games.game_engine import launch_game


def main():
    launch_game(gcd_game)


if __name__ == '__main__':
    main()
