from brain_games.games import primes_game
from brain_games.game_engine import launch_game


def main():
    launch_game(primes_game)


if __name__ == '__main__':
    main()
