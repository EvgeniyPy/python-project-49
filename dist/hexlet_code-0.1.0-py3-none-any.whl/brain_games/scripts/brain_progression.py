from brain_games.games import letsprogression
from brain_games.game_engine import launch_game


def main():
    launch_game(letsprogression)


if __name__ == '__main__':
    main()
